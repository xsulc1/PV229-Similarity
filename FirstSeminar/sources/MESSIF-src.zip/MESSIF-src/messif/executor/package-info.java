/**
 * Support for automatic execution by reflection.
 */
package messif.executor;

