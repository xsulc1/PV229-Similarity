
/**
 * Search algorithms base classes.
 */
package messif.algorithms;

