/**
 * Implementation of basic search algorithms.
 */
package messif.algorithms.impl;

