/**
 * Storage classes capable of holding {@link messif.objects.LocalAbstractObject objects}.
 */
package messif.buckets;

