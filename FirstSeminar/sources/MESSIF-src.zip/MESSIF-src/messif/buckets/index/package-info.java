/**
 * Bucket indexes for improved access.
 */
package messif.buckets.index;

