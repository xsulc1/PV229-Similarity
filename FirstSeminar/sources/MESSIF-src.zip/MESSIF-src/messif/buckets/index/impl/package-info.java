/**
 * Implementation of bucket indexes.
 */
package messif.buckets.index.impl;

