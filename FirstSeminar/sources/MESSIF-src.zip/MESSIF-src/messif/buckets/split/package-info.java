/**
 * Bucket splitting support.
 */
package messif.buckets.split;

