/**
 * Message-based networking support.
 * @see messif.network.MessageDispatcher
 */
package messif.network;

