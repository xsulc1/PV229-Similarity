/**
 * Utilization of resources using on-demand requirements of distributed structures.
 */
package messif.netcreator;

