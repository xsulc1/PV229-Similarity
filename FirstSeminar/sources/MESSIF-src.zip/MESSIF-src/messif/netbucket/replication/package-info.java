/**
 * Replication support for remote buckets.
 */
package messif.netbucket.replication;

