/**
 * Networked objects and buckets.
 * Allows to access a {@link messif.netbucket.RemoteBucket} as a regular
 * {@link messif.buckets.Bucket} using a {@link messif.network.MessageDispatcher messaging}.
 */
package messif.netbucket;

