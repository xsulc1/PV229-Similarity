/**
 * Implementation of data-manipulation operations.
 */
package messif.operations.data;

