/**
 * Generic classes for data manipulatioin and querying operations.
 */
package messif.operations;

