/**
 * Implementation of data querying operations.
 */
package messif.operations.query;

