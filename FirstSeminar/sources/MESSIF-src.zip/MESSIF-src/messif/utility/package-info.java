/**
 * Various utilities that does not fit anywhere else including
 * a main class for executing batch files.
 */
package messif.utility;

