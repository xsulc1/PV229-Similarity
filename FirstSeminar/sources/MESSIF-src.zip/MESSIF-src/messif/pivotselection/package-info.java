/**
 * Support for selection of representative objects (pivots).
 */
package messif.pivotselection;

