/**
 * Implementation of basic data objects.
 */
package messif.objects.impl;

