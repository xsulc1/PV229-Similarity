/**
 * Support for extended binary serialization of objects.
 */
package messif.objects.nio;

