/**
 * Support for text data. This package offers a methods for text transformations
 * such as stemming, diacritics removal, and so on.
 */
package messif.objects.text;

