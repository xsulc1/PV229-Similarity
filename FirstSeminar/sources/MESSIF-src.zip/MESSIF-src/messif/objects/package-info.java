/**
 * Metric data objects.
 */
package messif.objects;

