/**
 * Data object keys.
 * Allows to add additional meta-information to any data object.
 */
package messif.objects.keys;

