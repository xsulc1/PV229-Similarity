/**
 * Various utilities for working with collections of objects.
 */
package messif.objects.util;

