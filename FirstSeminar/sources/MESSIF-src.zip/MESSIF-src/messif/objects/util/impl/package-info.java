/**
 * Implementation of simple function evaluator.
 * It is used for computing aggregated distance functions.
 */
package messif.objects.util.impl;

