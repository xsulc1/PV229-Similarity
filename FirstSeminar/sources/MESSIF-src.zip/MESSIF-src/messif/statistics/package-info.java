/**
 * Statistic gathering support.
 */
package messif.statistics;

